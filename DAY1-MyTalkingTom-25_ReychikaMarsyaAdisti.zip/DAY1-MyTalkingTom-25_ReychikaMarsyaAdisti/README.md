# DAY1-MyTalkingTom-25_ReychikaMarsyaAdisti

**Nama Peserta:** Reychika Marsya Adisti  
**Jenis Misi:** Individu  
**Kegiatan:** Workshop Day 1 – *Building with AI, Managing Change with GitHub*  
**Tanggal:** 7 November 2026

## Deskripsi Repository
Repository ini dibuat sebagai tempat penyimpanan dan dokumentasi kegiatan Workshop Day 1. Di dalamnya terdapat website sederhana serta catatan materi, rangkuman pembelajaran, dan poin-poin penting yang diperoleh selama workshop.

## Tujuan Repository
Repository ini digunakan untuk:
1. Menyimpan dokumentasi dan catatan kegiatan workshop secara daring.
2. Mengumpulkan materi dan rangkuman pembelajaran dalam satu tempat.
3. Melatih penggunaan GitHub sebagai tempat penyimpanan dan pengelolaan repository.
4. Membiasakan penyusunan file dan dokumentasi secara rapi dan terstruktur.
5. Menggunakan README.md sebagai dokumentasi utama repository.

## Informasi Singkat Workshop
Workshop bertema **Building with AI, Managing Change with GitHub**. Materi membahas cara menyusun prompt yang baik untuk membantu proses pembuatan aplikasi dengan AI, serta pengenalan Git dan GitHub untuk mencatat, mengelola, dan menyimpan perubahan proyek. Pada sesi praktik, peserta diarahkan membuat aplikasi sederhana, menambahkannya ke Git, melakukan commit dan push ke GitHub, lalu memperbarui proyek.

## Materi atau Topik Workshop
1. **Prompt Engineering** – merancang instruksi agar AI memberikan hasil yang tepat, relevan, dan sesuai kebutuhan.
2. **Prompt AI dan konteks** – memahami prompt sebagai instruksi atau masukan kepada model AI. Konteks yang jelas membantu AI memahami tujuan pengguna.
3. **Struktur prompt** – menyusun prompt dengan unsur Role, Task, Context, dan Format.
4. **Pengenalan Git** – Git merupakan version control system untuk melacak perubahan file, termasuk siapa yang mengubah, kapan, dan apa yang diubah.
5. **Git dan GitHub** – Git digunakan untuk mengelola perubahan proyek secara lokal, sedangkan GitHub merupakan platform berbasis web untuk menyimpan repository Git secara online dan mendukung kolaborasi.
6. **Git Workflow** – mengenal working directory, staging area, dan Git directory.
7. **Perintah dasar Git dan GitHub** – mempelajari perintah untuk membuat repository, menambahkan perubahan, membuat commit, menghubungkan remote, mengirim perubahan, dan mengambil perubahan.
8. **Git Setup dan VS Code Setup** – memeriksa instalasi Git, mengatur identitas pengguna, serta memeriksa instalasi VS Code.
9. **Repository dan SSH Key** – mengenal cara membuat atau clone repository serta pengenalan autentikasi SSH ke GitHub.
10. **Praktik membuat aplikasi sederhana** – menggunakan AI untuk membantu membuat aplikasi, kemudian mengelola perubahan proyek dengan Git dan GitHub.

## Catatan atau Rangkuman Materi

### 1. Prompt Engineering
Prompt adalah instruksi atau masukan yang diberikan kepada model AI untuk memperoleh hasil tertentu. Prompt yang lebih jelas dan spesifik dapat membantu menghasilkan jawaban yang lebih sesuai. Struktur prompt yang dibahas dalam workshop terdiri dari:
- **Role:** peran yang diberikan kepada AI.
- **Task:** tugas yang harus dikerjakan.
- **Context:** informasi latar belakang atau kebutuhan pengguna.
- **Format:** bentuk hasil yang diinginkan.

### 2. Git dan GitHub
Git adalah version control system yang mencatat perubahan pada file atau proyek. GitHub adalah platform online untuk menyimpan repository Git dan mendukung kolaborasi. Keduanya saling melengkapi, tetapi memiliki fungsi yang berbeda.

### 3. Git Workflow
- **Working directory/tree:** tempat file proyek dikerjakan atau diubah.
- **Staging area:** tempat menyiapkan perubahan yang akan dimasukkan ke commit berikutnya.
- **Git directory:** tempat Git menyimpan metadata dan database objek yang dibutuhkan untuk mengelola proyek.

### 4. Perintah Dasar
| Perintah | Kegunaan |
|---|---|
| `git init` | Memulai repository Git baru. |
| `git add .` | Menambahkan perubahan file ke staging area. |
| `git add --all` atau `git add -A` | Menambahkan seluruh perubahan ke staging area. |
| `git commit -m "pesan"` | Menyimpan perubahan ke dalam riwayat repository. |
| `git remote add origin URL` | Menghubungkan repository lokal dengan repository remote. |
| `git clone URL` | Menyalin repository dari sumber remote. |
| `git push origin main` | Mengirim commit ke branch `main` pada repository remote. |
| `git pull origin main` | Mengambil dan menggabungkan perubahan dari branch `main` pada remote. |

### 5. Pengaturan Git dan VS Code
Setelah Git diinstal, versi Git dapat diperiksa dengan `git --version`. Identitas pengguna diatur menggunakan `git config --global user.name` dan `git config --global user.email`. Pengaturan dapat diperiksa dengan `git config --global --list`. Versi VS Code dapat diperiksa melalui terminal dengan `code --version`.

### 6. SSH Key
Workshop juga memperkenalkan SSH key sebagai salah satu cara autentikasi ke GitHub. Materi mencakup pembuatan SSH key, penambahan public key ke pengaturan GitHub, dan pemeriksaan koneksi menggunakan `ssh -T git@github.com`.

## Poin Penting atau Pengetahuan Baru
- Prompt yang memiliki tujuan, konteks, dan format yang jelas dapat membantu AI memberikan hasil yang lebih relevan.
- Git digunakan untuk melacak dan mengelola perubahan proyek.
- GitHub digunakan untuk menyimpan repository Git secara online dan mendukung kolaborasi.
- Staging area menjadi tempat memilih perubahan sebelum disimpan dalam commit.
- Commit menyimpan perubahan ke riwayat repository, sedangkan push mengirim commit ke repository remote.
- `git clone` dapat digunakan untuk menyalin repository yang sudah tersedia.
- Identitas Git perlu diatur agar informasi pembuat commit tercatat.
- README.md membantu orang lain memahami isi dan tujuan sebuah repository.

## Struktur Repository
```text
DAY1-MyTalkingTom-25_ReychikaMarsyaAdisti/
├── index.html   # Struktur dan isi website dokumentasi
├── style.css    # Tampilan website
├── script.js    # Interaksi pada website
└── README.md    # Dokumentasi utama dan rangkuman workshop
```

## Cara Menjalankan Website (Opsional)
1. Download atau clone repository ke komputer.
2. Buka folder repository menggunakan Visual Studio Code atau file manager.
3. Buka `index.html` menggunakan browser.
4. Pilih tombol pada kartu materi untuk membuka atau menutup ringkasan.
5. Gunakan checklist untuk menandai poin pembelajaran yang sudah dipahami.

Website dibuat menggunakan HTML, CSS, dan vanilla JavaScript tanpa library tambahan.

## Cara Menguji Interaksi Website
- Klik tombol **Baca ringkasan** pada kartu materi. Penjelasan materi akan ditampilkan.
- Klik kembali tombol tersebut. Penjelasan akan disembunyikan.
- Centang checklist. Indikator progres belajar akan bertambah.
- Hapus centang. Indikator progres akan berkurang.
- Ubah ukuran jendela browser untuk melihat penyesuaian tampilan pada ukuran layar berbeda.

---

Dokumentasi Workshop Day 1 oleh **Reychika Marsya Adisti**.
